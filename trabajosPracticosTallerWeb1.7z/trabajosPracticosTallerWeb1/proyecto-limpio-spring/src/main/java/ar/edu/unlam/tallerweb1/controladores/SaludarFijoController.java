package ar.edu.unlam.tallerweb1.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import ar.edu.unlam.tallerweb1.modelo.Farmacia;

@Controller
public class SaludarFijoController {
	
	@RequestMapping(path = "/saludar")
	public ModelAndView saludar(@RequestParam("persona") String nombre, @RequestParam("apellido") String apellido){
		
		ModelMap modelo = new ModelMap();
		//saludo es la clave que reprensenta el nombre del JSP
		modelo.put("saludo", "Holaaa!");
		
		//se envia parametros porURL
		modelo.put("personaSaludarNombre", nombre);
		modelo.put("personaSaludarApellido", apellido);
		
		//http://localhost:8080/proyecto-hibernate-springMVC-1/saludar?persona=Reyna&apellido=Rondo
		
		return new ModelAndView("saludo", modelo);
	}

}
