package ar.edu.unlam.tallerweb1.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import ar.edu.unlam.tallerweb1.modelo.Usuario;
import ar.edu.unlam.tallerweb1.servicios.ServicioLogin;
//le indica  a Spring que realiza una accion para la solicitud de l cliente
@Controller
public class ControladorListaUsuarios {

	@RequestMapping(path = "/lista/{cant}")
	public ModelAndView saludar(@PathVariable("cant") int cant){
		List<Usuario> lista = new ArrayList<Usuario>();
		
		ModelMap modelo = new ModelMap();
		for (int i = 0; i < cant; i++) {
			Usuario u = new Usuario("Usuario_"+i, null, "Admin_"+i);
			lista.add(u);
		}
		modelo.put("listaUsuarios", lista);
		
		return new ModelAndView("usuarios", modelo);
	}


}
